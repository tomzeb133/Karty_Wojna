#include "stdafx.h"
#include <iostream>
#include <stdlib.h>
#include <time.h>
#include <string.h>
#include <io.h>
#include <fcntl.h>
#include <conio.h>
#include <windows.h>
#include <fstream>

using namespace std;

#define nLoop 1000

typedef struct Karta
{
    char figura[20];
    char kolor[20];
	//A-12 pkt...2-0pkt, to bedzie ranga1
    int war;
	//A-10pkt,K-7pkt,D-4pkt,W-1pkt
	int ranga2;
	//1 jesli figura W..A
	int ranga3;
	//odwrotnie do war, ay sprawdzic korelacje
	int ranga4;
}Karta;

//Gracz posiada adresy do kart oraz pole liczba_kart
typedef struct Gracz
{
	Karta *reka[52];
	int liczba_kart;
}Gracz;

//funkcja sprawdza, czy przypadkiem karta nie jest juz wylosowana
bool wylosowana(int number,int tab[52])  
{

	for(int x=0; x<52; x++)
	{
		if(tab[x]==number)
			return true;
	}
	return false;
}

void printGracz(Gracz *gracz,char *napis,int sleep_interval) {

	if(gracz->liczba_kart<10)
		cout << napis << "("<<gracz->liczba_kart<<" )";
	else
		cout << napis << "("<<gracz->liczba_kart<<")";
	for(int y=0; y<gracz->liczba_kart; y++) {

		cout<< " "<<gracz->reka[y]->figura;
		_setmode(_fileno(stdout), _O_U16TEXT);
		if(strcmp("trefl",gracz->reka[y]->kolor)==0)
			std::wcout <<L"\u2663";
		if(strcmp("karo",gracz->reka[y]->kolor)==0)
			std::wcout <<L"\u2666";
		if(strcmp("kier",gracz->reka[y]->kolor)==0)
			std::wcout <<L"\u2665";
		if(strcmp("pik",gracz->reka[y]->kolor)==0)
			std::wcout <<L"\u2660";

		_setmode(_fileno(stdout), _O_TEXT);

		Sleep(sleep_interval);
	}
	cout << endl;
}

int gracz_stol(Gracz* gracz, Gracz* stol,int indeks_karty) {

	if(gracz->liczba_kart>0) {
		stol->reka[stol->liczba_kart]=gracz->reka[indeks_karty];
		stol->liczba_kart+=1;
		gracz->liczba_kart-=1;	
	
		//przesun karty graczowi
		if(indeks_karty==0)
			memcpy(gracz->reka+indeks_karty, gracz->reka+indeks_karty+1, sizeof(Karta*)*(gracz->liczba_kart) );
		else
			memcpy(gracz->reka+indeks_karty, gracz->reka+indeks_karty+1, sizeof(Karta*)*(gracz->liczba_kart-1) );
	}

	return 0;
}

int stol_gracz(Gracz* stol1,Gracz* stol2,Gracz* gracz) {

	if(stol1->liczba_kart>0) {
		memcpy(gracz->reka+gracz->liczba_kart, stol1->reka, sizeof(Karta*)*(stol1->liczba_kart));
		gracz->liczba_kart+=stol1->liczba_kart;
		stol1->liczba_kart=0;
	}
	if(stol2->liczba_kart>0) {
		memcpy(gracz->reka+gracz->liczba_kart, stol2->reka, sizeof(Karta*)*(stol2->liczba_kart));
		gracz->liczba_kart+=stol2->liczba_kart;
		stol2->liczba_kart=0;
	}

	for(int i=0; i<52; i++) {
		stol1->reka[i]=NULL;
		stol2->reka[i]=NULL;
	}

	return 0;
}

int gracz_gracz(Gracz* gracz1,Gracz* gracz2) {

	if(gracz2->liczba_kart>0) {
		memcpy(gracz1->reka+gracz1->liczba_kart, gracz2->reka, sizeof(Karta*)*(gracz2->liczba_kart));
		gracz1->liczba_kart += gracz2->liczba_kart;
		gracz2->liczba_kart = 0;
	}

	for(int i=0; i<52; i++) {	
		gracz2->reka[i]=NULL;
	}
	return 0;
}

//funkcja wybiera jaka karte gracz wyrzuca na stol w madrej grze
//na stole jest juz karta wyrzucona przez gracza przeciwnewgo
//jesli gracz moze wygrac to wygrywa
//jesli w obu przypadkach przegrywa wyrzuca slabsza karte
//jesli moze byc wojna to wybiera wojne
int gracz_choose(Gracz *s,Gracz *g2,Gracz *s2) {
	
	Karta *karta1,*karta2;

	if(g2->liczba_kart>1) {
		karta1 = g2->reka[0];
		karta2 = g2->reka[1];

		//wez starsza karte gracz
		if(karta1->war > karta2->war) {
			//pierwsza karta jest starsza
			//zobacz czy mniejsza wygrywa, jesli tak to ja poloz
			//jesli wojna jest mozliwa to ja robimy
			if(karta2->war > s->reka[s->liczba_kart-1]->war) {
				gracz_stol(g2,s2,1);
				return 0;
			} else if(karta1->war >= s->reka[s->liczba_kart-1]->war) {
				//jesli starsza karta wygrywa ze stolem to ja poloz
				gracz_stol(g2,s2,0);
				return 0;
			} else {
				//jesli zadna ze stolem nie wygrywa poloz mlodsza
				gracz_stol(g2,s2,1);
			} 
		} else if(karta1->war == karta2->war) {
					//jesli karty sa takie same to poloz pierwsza
					gracz_stol(g2,s2,0);

				} else {
					//druga karta jest starsza od pierwszej
					if(karta1->war > s->reka[s->liczba_kart-1]->war) {
						gracz_stol(g2,s2,0);
						return 0;
					} else if(karta2->war >= s->reka[s->liczba_kart-1]->war) {
						//jesli starsza karta wygrywa lub wojna ze stolem to ja poloz
						gracz_stol(g2,s2,1);
						return 0;
					} else {
						//jesli zadna ze stolem nie wygrywa poloz mlodsza
						gracz_stol(g2,s2,0);
					} 
				}
	} else {
			if(g2->liczba_kart==1) 
				gracz_stol(g2,s2,0);
			}

	return 0;
}

// glowna funkcja realizujaca logike gry w madra wojne. nowa funkcja aby nie lpmplikowac starej
//funkcja zwraca 1 jesli wygral gacz1 i 2 jesli wygral gracz2, zmienna winner on tym mowi
int bitwa(char wariant,Gracz *Gracz1, Gracz *Gracz2, Gracz *Stol1, Gracz *Stol2,int wyswietl,char typ_gry,int wygral_gracz,int *liczba_ruchow) 
{
	int winner=0;

	if(typ_gry=='m') {
		if(wygral_gracz!=2) {
		//gracz wyrzuca karte na stol
			gracz_stol(Gracz1,Stol1,0);
			gracz_choose(Stol1,Gracz2,Stol2);
		} else {
			gracz_stol(Gracz2,Stol2,0);
			gracz_choose(Stol2,Gracz1,Stol1);
		}
	} else {
		gracz_stol(Gracz1,Stol1,0);
		gracz_stol(Gracz2,Stol2,0);
	}

	(*liczba_ruchow)+=1;

	if(wyswietl!=0) {
		printGracz(Stol1,"\t\tStol1",0);
		printGracz(Stol2,"\t\tStol2",0);
	}

	if(Stol1->reka[0]->war > Stol2->reka[0]->war) {
		stol_gracz(Stol1,Stol2,Gracz1);
		if(wyswietl==1)
			cout<<"\t\tWygral GRACZ1!\n";
		return 1;
	}
	else 
		if(Stol1->reka[0]->war < Stol2->reka[0]->war) {
			stol_gracz(Stol2,Stol1,Gracz2);
			if(wyswietl==1)
				cout<<"\t\tWygral GRACZ2!\n";
			return 2;
		}
		else {
				//graj dopoki wojna sie skonczy
				if(wyswietl!=0)
					cout << "\t\tWOJNA !"<<endl;
				do {
					if(wariant=='a') {
						//cout<<"wariant a"<<endl;
						//sprawdz czy ktorys juz nie wygral
						if(Gracz1->liczba_kart < 2) {
								stol_gracz(Stol2,Stol1,Gracz2);
								gracz_gracz(Gracz2,Gracz1);
								if(Gracz1->liczba_kart==1)
									(*liczba_ruchow)+=1;
								return 2;
						} else if(Gracz2->liczba_kart < 2) {
									stol_gracz(Stol1,Stol2,Gracz1);
									gracz_gracz(Gracz1,Gracz2);
									if(Gracz2->liczba_kart==1)
										(*liczba_ruchow)+=1;
									return 1;
							} else {
									//gracze maja co najmniej 2 karty, gramy dalej, wyrzuc 2 karty
									for(int x=0; x<2; x++) {
										gracz_stol(Gracz1,Stol1,0);
										gracz_stol(Gracz2,Stol2,0);
										(*liczba_ruchow)+=1;
									}
							}
					} else {
						//wariant b
						//jesli ktorys gracz ma zero kart to drugi sie doklada, jesli ma to sam gra
						//jesli ma 0 kart drugi sie doklada
						if(Gracz1->liczba_kart == 0) {
								//teraz gracz2 sie doklada
								if(Gracz2->liczba_kart>=4)
									(*liczba_ruchow)+=2;
								else if(Gracz2->liczba_kart>=2)
											(*liczba_ruchow)+=1;

								gracz_stol(Gracz2,Stol1,0);
								gracz_stol(Gracz2,Stol1,0);
								gracz_stol(Gracz2,Stol2,0);
								gracz_stol(Gracz2,Stol2,0);
								if(Gracz2->liczba_kart == 0) {	
									stol_gracz(Stol2,Stol1,Gracz2);
									gracz_gracz(Gracz2,Gracz1);
									return 2;
								}
						} else if(Gracz1->liczba_kart == 1) {
									//wyrzuc swoja karte
									if(Gracz2->liczba_kart>=3)
										(*liczba_ruchow)+=2;
									else if(Gracz2->liczba_kart>=1)
											(*liczba_ruchow)+=1;

									gracz_stol(Gracz1,Stol1,0);
									//teraz gracz2 sie doklada
									gracz_stol(Gracz2,Stol1,0);
									gracz_stol(Gracz2,Stol2,0);
									gracz_stol(Gracz2,Stol2,0);
									if(Gracz2->liczba_kart == 0) {	
										stol_gracz(Stol2,Stol1,Gracz2);
										gracz_gracz(Gracz2,Gracz1);
										return 2;
									}
								} else if(Gracz2->liczba_kart == 0) {
										//teraz sprawdz liczbe kart gracza2 czy gracz1 musi sie dokladac, podobnie jak wyzej
										if(Gracz1->liczba_kart>=4)
											(*liczba_ruchow)+=2;
										else if(Gracz1->liczba_kart>=2)
											(*liczba_ruchow)+=1;

										gracz_stol(Gracz1,Stol2,0);
										gracz_stol(Gracz1,Stol2,0);
										gracz_stol(Gracz1,Stol1,0);
										gracz_stol(Gracz1,Stol1,0);
										if(Gracz1->liczba_kart == 0) {
											stol_gracz(Stol2,Stol1,Gracz1);
											gracz_gracz(Gracz1,Gracz2);
											return 1;
										}
									} else if(Gracz2->liczba_kart == 1) {
											//wyrzuc swoja karte

											if(Gracz1->liczba_kart>=3)
												(*liczba_ruchow)+=2;
											else if(Gracz1->liczba_kart>=1)
													(*liczba_ruchow)+=1;

											gracz_stol(Gracz2,Stol2,0);
											//teraz gracz1 sie doklada
											gracz_stol(Gracz1,Stol2,0);
											gracz_stol(Gracz1,Stol1,0);
											gracz_stol(Gracz1,Stol1,0);
											if(Gracz1->liczba_kart == 0) {
												stol_gracz(Stol2,Stol1,Gracz1);
												gracz_gracz(Gracz1,Gracz2);
												return 1;
											}
										} else {
													//gracz maja karty niech wykladaja sami
													gracz_stol(Gracz1,Stol1,0);
													gracz_stol(Gracz1,Stol1,0);
													gracz_stol(Gracz2,Stol2,0);
													gracz_stol(Gracz2,Stol2,0);
													(*liczba_ruchow)+=2;
												}
					}

					if(wyswietl!=0) {
						printGracz(Stol1,"\t\tStol1",0);
						printGracz(Stol2,"\t\tStol2",0);
					}
				} while(Stol1->reka[Stol1->liczba_kart-1]->war==Stol2->reka[Stol2->liczba_kart-1]->war);

				//sprawdz kto wygral
				if(Stol1->reka[Stol1->liczba_kart-1]->war > Stol2->reka[Stol2->liczba_kart-1]->war) {
					stol_gracz(Stol1,Stol2,Gracz1);
					if(wyswietl==1)
						cout<<"\t\tWygral GRACZ1!\n";
					winner = 1;
				}
				else {
					stol_gracz(Stol2,Stol1,Gracz2);
					if(wyswietl==1)
						cout<<"\t\tWygral GRACZ2!\n";
					winner = 2;
				}
			}
		if(wyswietl!=0)
			cout<<endl;

		return winner;
}


void losuj_karty(Karta karty[],Gracz* gracz,int tab[52],int liczba_kart) {
	
	int indeks;

	for(int k=0; k<liczba_kart; k++) {
		do {
			indeks=(52-liczba_kart*2)+rand()%(liczba_kart*2);
			if(wylosowana(indeks,tab)==false) {
				gracz->reka[k]=&karty[indeks];
				tab[indeks]=indeks;
				break;
			}
		}while (1==1);
	}
	gracz->liczba_kart = liczba_kart;
}


//funkcja do realizacji symulacji
//zwraca liczbe ruchow w danym rozdaniu
//argumenty:
//wariant - A lub B
//numer talii 1 - 20 kart,2-24 kartr....9-52 karty
int symulacja(FILE *myfile,char wariant,int numer_talii,Gracz* g1,Gracz* g2,Gracz* s1,Gracz* s2,char* figury[],char* kolory[],Karta karty[],int display,char typ_gry,char tryb,int *liczba_ruchow) {

	int wylosowane_indeksy[52];
	int tura=0,winner=0;
	int g1_ranga1=0,g1_ranga2=0,g1_ranga3=0,g1_ranga4=0;
	int g2_ranga1=0,g2_ranga2=0,g2_ranga3=0,g2_ranga4=0;
	Gracz* tmp;
	char str[30],tmpstr[10];

	//inicjalizacja graczy i stolu
	for(int i=0; i<52; i++) {
		wylosowane_indeksy[i]=-1;
		g1->reka[i]=NULL;
		g2->reka[i]=NULL;
		s1->reka[i]=NULL;
		s2->reka[i]=NULL;
	}

	s1->liczba_kart = 0;
	s2->liczba_kart = 0;
	g1->liczba_kart = 0;
	g2->liczba_kart = 0;

	if(tryb=='d') {
		cout <<"\n\nLOSOWANIE "<<10+2*numer_talii<<" KART...\n";
	}

	losuj_karty(karty,g1,wylosowane_indeksy,10+2*numer_talii);
	if(display==1) {
		printGracz(g1,"GRACZ1",300);
	}

	losuj_karty(karty,g2,wylosowane_indeksy,10+2*numer_talii);
	if(display==1) {
		printGracz(g2,"GRACZ2",300);
	}

	//oblicz rangi graczy
	for(int i=0;i<(10+2*numer_talii);i++) {
		g1_ranga1+=g1->reka[i]->war;
		g1_ranga2+=g1->reka[i]->ranga2;
		g1_ranga3+=g1->reka[i]->ranga3;
		g1_ranga4+=g1->reka[i]->ranga4;
		g2_ranga1+=g2->reka[i]->war;
		g2_ranga2+=g2->reka[i]->ranga2;
		g2_ranga3+=g2->reka[i]->ranga3;
		g2_ranga4+=g2->reka[i]->ranga4;
	}

	//graj az ktos nie wygra
	do {
		if(typ_gry=='k')
			winner = bitwa(wariant,g1, g2, s1, s2,display,typ_gry,0,liczba_ruchow);
		else
			winner = bitwa(wariant,g1, g2, s1, s2,display,typ_gry,winner,liczba_ruchow);

		if(display==1) {
			printGracz(g1,"\nGRACZ1",0);
			printGracz(g2,"GRACZ2",0);
		}

		tura++;
		if(tura > 1000) {
			break;
		}
	} while(g1->liczba_kart != ((10+2*numer_talii)*2) && g2->liczba_kart != ((10+2*numer_talii)*2));
	
	//zobacz kto wygral
	//format pliku 1 jesli wygral 0 jesli przegral
	//ranga1,ranga2,ranga3,ranga4,1
	//zapis danych do pliku, potem obliczenie korelacji w Excelu
	if(myfile !=NULL) {
		if(g1->liczba_kart == (10+2*numer_talii)*2) {
			
			fprintf(myfile,"%d,%d,%d,%d,1\n",g1_ranga1,g1_ranga2,g1_ranga3,g1_ranga4);
			fprintf(myfile,"%d,%d,%d,%d,0\n",g2_ranga1,g2_ranga2,g2_ranga3,g2_ranga4);

		} else if(g2->liczba_kart == (10+2*numer_talii)*2) {
				fprintf(myfile,"%d,%d,%d,%d,0\n",g1_ranga1,g1_ranga2,g1_ranga3,g1_ranga4);
				fprintf(myfile,"%d,%d,%d,%d,1\n",g2_ranga1,g2_ranga2,g2_ranga3,g2_ranga4);

		} else if(g2->liczba_kart > g1->liczba_kart) {
					fprintf(myfile,"%d,%d,%d,%d,0\n",g1_ranga1,g1_ranga2,g1_ranga3,g1_ranga4);
					fprintf(myfile,"%d,%d,%d,%d,1\n",g2_ranga1,g2_ranga2,g2_ranga3,g2_ranga4);
		}
	}
	
	return tura;
}


//eksperyment 1 najwyższy poziom satysfakcji
//dzieci sie szybko nudza dlatego przyjmuje ze najnizsza srednia ruchow aby wygrac gre na najwyzszy poziom satysfakcji
//przujmuje ze wariant A dla talii 20 kart bedzie to gwarantowac, symulacja to pokaze
int main()
{
	Karta karty[52];
    char *figury[] = {" 2"," 3"," 4"," 5"," 6"," 7"," 8"," 9","10"," W"," D"," K"," A"};
    char *kolory[] = {"trefl","karo","kier","pik"};
	Gracz Gracz1, Gracz2,Stol1,Stol2;
	int rozmiar_talii,tura;
	int liczba_ruchow=0,liczba_tur=0;
	float srednia_tur=0,srednia_ruchow=0;;
	char tryb,wariant,rozmiar,typ_gry;
	FILE  *fileAk,*fileBk,*fileAm,*fileBm;

	fileAk = fopen("korelacjaAklasyczna.txt","a");
	fileBk = fopen("korelacjaBklasyczna.txt","a");
	fileAm = fopen("korelacjaAmadra.txt","a");
	fileBm = fopen("korelacjaBmadra.txt","a");
	if(fileAk == NULL || fileBk==NULL || fileAm==NULL || fileBm==NULL) {
			cout << "Error: nie mozna dostac uchwytu do pliku! exit";
			exit(1);
	}

	srand(time(NULL));

	//inicjalizacja talii kart, obliczenie rangi karty
    for(int y=0; y<52; y++) {
        strcpy(karty[y].kolor, kolory[y%4]);
        strcpy(karty[y].figura,figury[y/4]);
        karty[y].war = y/4;
		switch(karty[y].war) {
			case 12:karty[y].ranga2=10;
				break;
			case 11:karty[y].ranga2=7;
				break;
			case 10:karty[y].ranga2=4;
				break;
			case 9:karty[y].ranga2=1;
				break;
			default:karty[y].ranga2=0;
		}
		if(karty[y].war>=9)
			karty[y].ranga3 = 1;
		else
			karty[y].ranga3 = 0;

		karty[y].ranga4=12 - karty[y].war;
    }

	cout << "Gra w wojne\n\n";
		do{
		cout << "podaj tryb (d-demo programu s-symulacja q-quit): ";
		cin >> tryb;
	}while(tryb != 'd' && tryb !='s' && tryb !='q');

	cout<<endl;

	if(tryb=='d') {
		do{
			cout << "podaj wariant (a lub b): ";
			cin >> wariant;
		}while(wariant != 'a' && wariant !='b');

		do{
			cout << "podaj rozmiar talii (0-8): ";
			cin >> rozmiar;
			rozmiar_talii = rozmiar-'0'; 
		}while(rozmiar_talii < 0 || rozmiar_talii > 8);

		do{
			cout << "podaj typ gry (k-klasyczna m-madra): ";
			cin >> typ_gry;
		}while(typ_gry != 'k' && typ_gry !='m');

		if(typ_gry == 'k')
			cout <<"\nKlasyczna gra w wojne\n";
		else
			cout <<"\nMadra gra w wojne\n";

		symulacja(NULL,wariant,rozmiar_talii,&Gracz1,&Gracz2,&Stol1,&Stol2,figury,kolory,karty,1,typ_gry,tryb,&liczba_ruchow);
		if(Gracz1.liczba_kart == ((10+2*rozmiar_talii)*2))
			cout << "Wygral gracz1\n";
		else
			cout << "Wygral gracz2\n";
		cout<<"liczba ruchow =  "<<liczba_ruchow<<endl;
	}else if(tryb=='s') {
		//symulacja
		for(int i=0;i<9;i++) {
			wariant='a';
			liczba_tur=0;
			liczba_ruchow=0;
			cout <<"\nSymulacja wojna klasyczna A: talia="<<(10+2*i)*2<< " kart";
			for(int z=0;z<nLoop;z++) {
				tura = symulacja(fileAk,wariant,i,&Gracz1,&Gracz2,&Stol1,&Stol2,figury,kolory,karty,0,'k',tryb,&liczba_ruchow); 
				liczba_tur+=tura;
			}

			srednia_tur =liczba_tur/nLoop;
			srednia_ruchow =liczba_ruchow/nLoop;
			//cout<<"  srednia bitew =  "<<srednia_tur;
			cout<<"  srednia ruchow =  "<<srednia_ruchow<<endl;
			
			liczba_tur=0;
			liczba_ruchow=0;
			wariant='b';
			cout <<"Symulacja wojna klasyczna B: talia="<<(10+2*i)*2<< " kart";
			for(int z=0;z<nLoop;z++) {
				tura = symulacja(fileBk,wariant,i,&Gracz1,&Gracz2,&Stol1,&Stol2,figury,kolory,karty,0,'k',tryb,&liczba_ruchow); 
				liczba_tur+=tura;
			}

			srednia_tur =liczba_tur/nLoop;
			srednia_ruchow =liczba_ruchow/nLoop;
			//cout<<"  srednia bitew =  "<<srednia_tur;
			cout<<"  srednia ruchow =  "<<srednia_ruchow<<endl;


			liczba_tur=0;
			liczba_ruchow=0;
			wariant='a';
			cout <<"Symulacja wojna madra     A: talia="<<(10+2*i)*2<< " kart";
			for(int z=0;z<nLoop;z++) {
				tura = symulacja(fileAm,wariant,i,&Gracz1,&Gracz2,&Stol1,&Stol2,figury,kolory,karty,0,'m',tryb,&liczba_ruchow); 
				liczba_tur+=tura;
			}

			srednia_tur =liczba_tur/nLoop;
			srednia_ruchow =liczba_ruchow/nLoop;
			//cout<<"  srednia bitew =  "<<srednia_tur;
			cout<<"  srednia ruchow =  "<<srednia_ruchow<<endl;

			liczba_tur=0;
			liczba_ruchow=0;
			wariant='b';
			cout <<"Symulacja wojna madra     B: talia="<<(10+2*i)*2<< " kart";
			for(int z=0;z<nLoop;z++) {
				tura = symulacja(fileBm,wariant,i,&Gracz1,&Gracz2,&Stol1,&Stol2,figury,kolory,karty,0,'m',tryb,&liczba_ruchow); 
				liczba_tur+=tura;
			}

			srednia_tur =liczba_tur/nLoop;
			srednia_ruchow =liczba_ruchow/nLoop;
			//cout<<"  srednia bitew =  "<<srednia_tur;
			cout<<"  srednia ruchow =  "<<srednia_ruchow<<endl;
		
		}
	}

	//symulacja dowodzi ze wariant A z talia 20 kart ma najnizsza srednia liczba ruchow aby wygrac i najwyzszy poziom satysfakcji
	fclose(fileAk);
	fclose(fileBk);
	fclose(fileAm);
	fclose(fileBm);

	cout<<"press any key to exit...";
	getch();
	return 0;
}